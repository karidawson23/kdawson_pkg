#This function will create a plot of the gps coordinates of the nests along the beach in panama 

