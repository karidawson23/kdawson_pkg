calc_den <- function (len, width, height ){ 
  vol <- calc_vol (len, width, height)
  mass <- calc_mass (len)
  density <- mass/volume
  return(density)

  
  
square_number <- function(x) {
squared <- x^2
return(squared)
if (a >2){ }

calu_shrub_vol <- function(height, length, width) {
  volume <- height *length * width
  return(volume)
}
calu_shrub_vol(2, 4, 6)


name_of_function <- function (number_one =1, number_two = 2){
  product <- number_one * number_two
  return(product)
}

cascasding functions



division <- function(divide_by = 2){
  result <- name_of_function()
  quptient <- result/2
  return()
}