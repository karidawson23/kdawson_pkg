# this function will be able to sort, group, and mutate data from a data set

