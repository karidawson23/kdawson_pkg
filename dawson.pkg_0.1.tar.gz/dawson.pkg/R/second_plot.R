# I would like this plot to be able to effectively show the number of turtles and nests throughout the nesting season. I would maybe like to show the number of eggs each of the turtles laid. 


