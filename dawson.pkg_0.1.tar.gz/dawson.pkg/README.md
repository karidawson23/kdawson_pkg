# dawson.pkg

## An R package for processing sea turtle nesting data

This is for sea turtle biologists. This plots GPS coordinates, shows the relationship between different biomarkers and reproductive output and carapce size. It can even show individule turtle nesting data. This package also has the capacity to run a 4 parametric logistic scale anaylisis for those who are running some sort of assay.

hiiii
